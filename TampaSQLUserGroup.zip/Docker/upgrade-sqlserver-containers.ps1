<#
docker volume ls
docker volume rm sqlvol -f
#>
# REMOVE IF VOLUME EXISTS
docker volume ls
docker volume rm mssqldir -f
# CREATE VOLUME
docker volume create mssqldir
# LAUNCH SQL SERVER 2019 CONTAINER
docker pull mcr.microsoft.com/mssql/server:2017-latest
$ContainerName = 'APPSQL'
$PW = 'NjS@p!2017'
docker run -e 'ACCEPT_EULA=Y' `
-e "SA_PASSWORD=$PW" `
-p 1460:1433 `
--name $ContainerName `
-v mssqldir:/var/opt/mssql `
-d mcr.microsoft.com/mssql/server:2017-latest
# CONNECT TO SQL
docker exec -it $ContainerName /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P $PW
<#
  1- CREATE DATABASE upgradesql
  2- CREATE TABLE tampa
  3- INSERT INTO tampa VALUES (1),(2),(3)
  4- SELECT * FROM tampa
  4- PRINT @@VERSION
#>
# EXIT
exit
# GRANT ACCESS
docker exec -it $ContainerName "bash"

chgrp -R 0 /var/opt/mssql
chmod -R g=u /var/opt/mssql
# EXIT
exit
# STOP THE CONTAINER
docker stop $ContainerName
# DEPLOY SQL SERVER 2019
docker pull mcr.microsoft.com/mssql/server:2019-latest
$ContainerName = 'APPSQL1'
docker run -e 'ACCEPT_EULA=Y' `
-e "SA_PASSWORD=$PW" `
-p 1460:1433 `
--name $ContainerName `
-v mssqldir:/var/opt/mssql `
-d mcr.microsoft.com/mssql/server:2019-latest
# CONNECT TO SQL
docker exec -it $ContainerName /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P $PW

# RENAME CONTAINER
# STOP CONTAINER
docker stop $ContainerName
# RENAME CONTAINER
docker rename APPSQL APPSQL17
docker rename APPSQL1 APPSQL
# GO LIVE
docker start APPNJSQL
# CHECK DOCKER PROCESS
docker ps 
# CONNECT TO SQL
docker exec -it APPNJSQL /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P $PW

# CLEAN UP
# STOP ALL CONTAINERS
docker container stop $(docker ps -q)
# REMOVE ALL CONTAINERS
docker rm $(docker ps -aq)
# DELETE EVERYTHING
docker system prune -a --volumes
# docker system prune --all
