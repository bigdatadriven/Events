#docker search microsoft/mssql
# CHECK FOR ALL AVAILABLE SQL SERVER DOCKER CONTAINER
$repository = invoke-webrequest https://mcr.microsoft.com/v2/mssql/server/tags/list
$repository.Content
# PULL IMAGE FROM DOCKER HUB
docker pull mcr.microsoft.com/mssql/server:2019-CU5-ubuntu-18.04
# DISPLAY ALL IMAGES
docker images -a
# RUN THE IMAGE AS A CONTAINER
$Container_Name = "Tampa_SQL_User_Group"
docker run --name $Container_Name `
    -e 'ACCEPT_EULA=Y' `
    -e 'SA_PASSWORD=P@$$w0rD10' `
    -p 1433:1433 `
    -d mcr.microsoft.com/mssql/server:2019-CU5-ubuntu-18.04
# CONTAINER ID RETURNED AS Server name, ComputerNamePhysicalNetBIOS, and MachineName name
docker exec -it $Container_Name /opt/mssql-tools/bin/sqlcmd `
    -S localhost -U SA -P 'P@$$w0rD10' `
    -Q "SELECT CAST(@@SERVERNAME AS VARCHAR(50))SERVERNAME,
    CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS VARCHAR(50))ComputerNamePhysicalNetBIOS,
    CAST(SERVERPROPERTY('MachineName') AS VARCHAR(50))MachineName,
    CAST(SERVERPROPERTY('ServerName') AS VARCHAR(50))ServerName
"
# DELETE THIS CONTAINER
docker rm -f $Container_Name 
# DEPLOY SQL SERVER CONTAIN INCLUDE HOST NAME	
docker run --name $Container_Name `
    -e 'SA_PASSWORD=P@$$w0rD10' `
    -p 1455:1433 `
    -e "ACCEPT_EULA=Y" `
    --hostname $Container_Name `
    -d mcr.microsoft.com/mssql/server:2019-CU5-ubuntu-18.04
# LOOK BETTER NOW
docker exec -it $Container_Name /opt/mssql-tools/bin/sqlcmd `
    -S localhost -U SA -P 'P@$$w0rD10' `
    -Q "SELECT CAST(@@SERVERNAME AS VARCHAR(50))SERVERNAME,
    CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS VARCHAR(50))ComputerNamePhysicalNetBIOS,
    CAST(SERVERPROPERTY('MachineName') AS VARCHAR(50))MachineName,
    CAST(SERVERPROPERTY('ServerName') AS VARCHAR(50))ServerName
"
# CONNECT AND QUERY SQL SERVER CONTAINER
# CREATE DATABASE, TABLE, INSERT DATA, AND SELECT
docker exec -it $Container_Name /opt/mssql-tools/bin/sqlcmd `
    -S localhost -U SA -P 'P@$$w0rD10' `
    -Q "SET NOCOUNT ON;
       CREATE DATABASE DemoTest;
       GO
       USE DemoTest;
       GO
       CREATE TABLE try_sql_docker(FieldName VARCHAR(50));
       INSERT INTO try_sql_docker 
       SELECT 'It works!!!';
       GO
       SELECT * FROM try_sql_docker;
"
# GET ALL RUNNING CONTAINERS
docker ps
# GET ALL AVAIALABLE CONTAINER
docker ps -a
# STOP A CONTAINER
docker container stop $Container_Name
# STOP ALL CONTAINER
docker container stop $(docker ps -q)
# START A CONTAINER
docker container start $Container_Name
# STOP ALL CONTAINER
docker container start $(docker ps -q) 
# STOP A SINGLE CONTAINER
docker container restart $Container_Name
# STOP ALL RUNNING CONTAINERS
docker restart $(docker ps -q)
# GET DOCKER CONFIGURATION DETAILS
docker inspect $Container_Name
# GET ASSOCIATE DOCKER CONTAINER IMAGE AND PORT
docker container ls --format 'table {{.ID}}\t{{.Image}}\t{{.Status}}\t{{.Networks}}\t{{.Ports}}\t{{.Names}}'
# DISPLAY ALL EXISTED CONTAINERS
docker container ls -a --filter status=exited --filter status=created
# LET'S COPY AND RESTORE "AdventureWorks2017" DATABASE
# CREATE A NEW FOLDER WITHIN DOCKER CONTAINER
docker exec -it $Container_Name mkdir /var/opt/mssql/sqlbackup
# COPY BACKUP FILE FROM LOCAL TO DOCKER CONTAINER DRIVE
docker cp C:\sqlbackup\AdventureWorks2017.bak Tampa_SQL_User_Group:/var/opt/mssql/sqlbackup
# NAVIGATE TO DOCKER CONTAINER DIRECTORY TO VERIFY IF THE BACKUP FILE EXISTS
docker exec -it $Container_Name bash
# EXIT
exit
# VERIFY IF DB EXISTS
docker exec -it $Container_Name /opt/mssql-tools/bin/sqlcmd `
    -S localhost -U SA -P 'P@$$w0rD10' `
    -Q "SELECT name FROM sys.databases
        GO
"
# VIRIFY EXISTING DATABASE BEFORE RESTORING 
docker exec -it $Container_Name /opt/mssql-tools/bin/sqlcmd `
    -S localhost -U SA -P 'P@$$w0rD10' `
    -Q "
    USE [master]
    RESTORE DATABASE [AdventureWorks2017] 
    FROM  DISK = N'/var/opt/mssql/sqlbackup/AdventureWorks2017.bak' WITH  FILE = 1,  
    MOVE N'AdventureWorks2017' TO N'/var/opt/mssql/data/AdventureWorks2017.mdf',  
    MOVE N'AdventureWorks2017_log' TO N'/var/opt/mssql/data/AdventureWorks2017_log.ldf',  
    NOUNLOAD,  STATS = 10
    GO    
"
# VERIFY IF THE NEW DATABASE CREATED
docker exec -it $Container_Name /opt/mssql-tools/bin/sqlcmd `
    -S localhost -U SA -P 'P@$$w0rD10' `
    -Q "SELECT name FROM sys.databases
        GO
"
# LIST ALL VOLUME
docker volume ls
# CREATE CONTAINER VOLUME
docker volume create sqldbdata
# INSPECT THE VOLUME METADATA
docker volume inspect sqldbdata
# BASIC WAY TO PERSIST DATA IN SQL SERVER CONTAIN
$SQLServerName = "LocalDrive"
$pw = "Test!123"
docker run -e "ACCEPT_EULA=Y"`
    -e "MSSQL_SA_PASSWORD=$pw"`
    --name "$SQLServerName"`
    --hostname "$SQLServerName" `
    -p "1420:1433"`
    -v 'sqldbdata:/var/opt/mssql' `
    -d "mcr.microsoft.com/mssql/server:2019-CU5-ubuntu-18.04"
# DELETE CONTAINER
docker rm -f $SQLServerName
# RE PUBLISH SAME CONTAINER USING WINDOWS MAP DROVE
$SQLServerName = "LocalDrive"
$pw = "Test!123"
docker run -e "ACCEPT_EULA=Y"`
    -e "MSSQL_SA_PASSWORD=$pw"`
    --name "$SQLServerName"`
    --hostname "$SQLServerName" `
    -p "1420:1433"`
    -v 'C:\sqldir\tampasql\mssql_1\docker:/var/opt/mssql' `
    -d "mcr.microsoft.com/mssql/server:2019-CU5-ubuntu-18.04"
# CHECK THE CURRENT OR LIVE LOG: -f or --follow
docker exec -it $SQLServerName /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P $pw
docker logs -f $SQLServerName
# WILL SHOW THE LAST NUMBER OF LOG LINES YOU SPECIFY: -t or --tail
docker logs $SQLServerName --tail N
# DISPLAY EXTRA DETAILS: --details
docker logs $SQLServerName --details
# LIST THE LOG
docker logs $SQLServerName
# LET'S INTERACT WITH SQL SERVER
docker exec -it $SQLServerName bash
# KIND OF INTERMEDIATE BUT NOT RECOMMENDED WAY
$SQLServerName = "Demo_2"
$pw = "Test!123"
docker run -e "ACCEPT_EULA=Y"`
    -e "MSSQL_SA_PASSWORD=$pw"`
    --name "$SQLServerName"`
    --hostname "$SQLServerName" `
    --env MSSQL_DATA_DIR="/var/opt/mssql/data" `
    --env MSSQL_LOG_DIR="/var/opt/mssql/dblog" `
    --env MSSQL_BACKUP_DIR="/var/opt/mssql/backup" `
    --env MSSQL_AGENT_ENABLED="true" `
    -p "1421:1433"`
    -v "C:\sqldir\tampasql\mssql_2\data:/var/opt/mssql/data"`
    -v "C:\sqldir\tampasql\mssql_2\log:/var/opt/mssql/dblog"`
    -v "C:\sqldir\tampasql\mssql_2\errorlog:/var/opt/mssql/log"`
    -v "C:\sqldir\tampasql\mssql_2\backup:/var/opt/mssql/backup"`
    -v "C:\sqldir\tampasql\mssql_2\secrets:/var/opt/mssql/secrets"`
    -d "mcr.microsoft.com/mssql/server:2019-CU5-ubuntu-18.04"
# LET'S INTERACT WITH SQL SERVER
docker exec -it $SQLServerName /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P $pw
<#
docker run --name $Container_Name mcr.microsoft.com/mssql/server:2019-CU5-ubuntu-18.04 --memory 4096m --cpus 2 -it -p '1433:1433'
#>
# CREATE DATABASE 
# DELETE DATABASE FILES
# CLEAN UP
docker container rm -f $(docker ps -a -q)
