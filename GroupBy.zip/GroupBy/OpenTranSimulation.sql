USE master
GO
IF DB_ID('Slowness') IS NOT NULL
DROP DATABASE [Slowness]
GO
CREATE DATABASE [Slowness]
GO
USE [Slowness]
GO
IF OBJECT_ID('Address') IS  NOT NULL 
DROP TABLE [Address]
GO
CREATE TABLE [dbo].[Address](
	[AddressLine1] [nvarchar](60) NOT NULL,
	[AddressLine2] [nvarchar](60) NULL,
	[City] [nvarchar](30) NOT NULL,
	[StateProvinceID] [int] NOT NULL,
	[PostalCode] [nvarchar](15) NOT NULL,
	[SpatialLocation] [geography] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
INSERT INTO dbo.[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2017].[Person].[Address]
GO
CREATE INDEX ixd_city ON [dbo].[Address](City);
GO
-- BUSINESS REPORT
USE [Slowness]
GO
SELECT * FROM [dbo].[Address]  WHERE City = 'London'
--1: difference between open trasaction and blocking
USE [Slowness]
GO
BEGIN TRAN
UPDATE A
SET AddressLine1 = '255 Irving Street'
FROM [dbo].[Address] AS A 
WHERE City = 'London'

--open a new session and run this select statement
USE [Slowness]
GO
SELECT * FROM [dbo].[Address]  WHERE City = 'London'

--open a new session and run this select statement
BEGIN TRAN
UPDATE p
SET PersonType='SP'
FROM [AdventureWorks2017].[Person].[Person] p where PersonType='SP'

--use step 1 session for this below query
SELECT * FROM [AdventureWorks2017].[Person].[Person] p where PersonType='SP'
-- Real Time Example
GO
USE [Slowness]
GO
/****** Object:  StoredProcedure [dbo].[usp_SimulationOpenTransaction]    Script Date: 5/11/2020 6:31:34 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_SimulationOpenTransaction]
@Delay TINYINT = 1
AS
DECLARE @WaitFor CHAR(8);
BEGIN
    BEGIN TRAN
		IF (@Delay BETWEEN 1 AND 4)
		BEGIN
			UPDATE Ad
				SET Ad.AddressLine1=OpenTran.AddressLine1 -- SELECT *
			FROM(
				SELECT TOP  25 PERCENT * FROM dbo.Address ORDER BY NEWID()    
			)OpenTran
			INNER JOIN dbo.Address Ad
			ON OpenTran.AddressLine1 = Ad.AddressLine1
			SET @WaitFor = '00:00:0'+CAST(@Delay AS CHAR(1))
		END
		ELSE IF(@Delay BETWEEN 5 AND 6)
		BEGIN
			INSERT INTO dbo.[Address]
			SELECT TOP  25 PERCENT * FROM dbo.[Address] ORDER BY NEWID() 
		END
		ELSE IF(@Delay BETWEEN 7 AND 9)
		BEGIN
			DELETE TOP  (1000) from dbo.[Address];
		END
        WAITFOR DELAY @WaitFor
    COMMIT
END


