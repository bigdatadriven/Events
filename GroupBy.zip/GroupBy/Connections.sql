
--Step: 1 Take a look at Disk sizes

exec xp_fixeddrives;


--Step: 2- number of connections per each DB:
  SELECT DB_NAME(dbid) as DBName, COUNT(dbid) as NumberOfConnections, loginame as LoginName 
  FROM sys.sysprocesses WHERE dbid > 0 GROUP BY dbid, loginame�

--Step: 3- Total number of connections
/*
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE ;
GO
EXEC sp_configure 'user connections', 325 ;
GO
RECONFIGURE;
GO
*/
EXEC sp_configure 'user connections'
go
SELECT COUNT(dbid) as TotalConnections 
FROM sys.sysprocesses WHERE dbid > 0

--Step: 4 --What type of connections
with ActiveConnections as(
select�session_id,�program_name
from�sys.dm_exec_sessions
--where�program_name�like�'VirtualPass%'
)
select * from ActiveConnections 
where program_name is not null;

--Step: 5 Get Disk sizes

exec xp_fixeddrives;

--Step: 6 --Get the Actual Queries
with SessionQueriesText as(
SELECT spid, 
       loginame, 
       status, 
       cmd, 
       program_name, 
       hostname, 
       login_time, 
       last_batch, 
       (SELECT text 
        FROM   sys.Dm_exec_sql_text(sql_handle))AS SQLH 
FROM   master.dbo.sysprocesses WITH (nolock) 
WHERE  spid <>@@SPID
       --AND program_name LIKE '%Studio%' 
)
select * from SessionQueriesText where SQLH is not null