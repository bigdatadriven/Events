USE master
GO
IF DB_ID('Products') IS NOT NULL
DROP DATABASE [Products]

USE master
GO
CREATE DATABASE [Products]
GO
USE [Products]
GO

CREATE TABLE [dbo].[Address](
	[AddressLine1] [nvarchar](60) NOT NULL,
	[AddressLine2] [nvarchar](60) NULL,
	[City] [nvarchar](30) NOT NULL,
	[StateProvinceID] [int] NOT NULL,
	[PostalCode] [nvarchar](15) NOT NULL,
	[SpatialLocation] [geography] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
INSERT INTO products.dbo.[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2017].[Person].[Address]
GO
--no statistics
SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO

--this query, will automatically create statistics
SELECT * FROM dbo.[Address] WHERE city='London'
GO

SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO

DBCC SHOW_STATISTICS(N'[dbo].[Address]', <StatName>)
DBCC SHOW_STATISTICS(N'[dbo].[Address]', <StatName>)WITH HISTOGRAM
GO
SELECT [City] , COUNT(*)[Rows] FROM [AdventureWorks2017].[Person].[Address] GROUP BY [City] ORDER BY [City]
GO

CREATE INDEX NC_idx_AddrCity on dbo.[Address](city)
GO

DBCC SHOW_STATISTICS('[dbo].[Address]','NC_idx_AddrCity') WITH STAT_HEADER;
GO

SELECT COUNT(*) from dbo.[Address]
GO
-- THE OTHER WAY
SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO
-- 832
INSERT INTO products.dbo.[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2017].[Person].[Address]
WHERE City in('London','Paris')
GO
-- STEP 1:
-- This is not really a good way to see if statistics is update to date
DBCC SHOW_STATISTICS('[dbo].[Address]','NC_idx_AddrCity') WITH STAT_HEADER;
GO
DBCC SHOW_STATISTICS(N'[dbo].[Address]', _WA_Sys_00000003_22AA2996)WITH HISTOGRAM;
GO
SELECT City,COUNT(*) FROM dbo.[Address] GROUP BY City ORDER BY City
-- GO
-- STEP 2:
SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO
-- STEP 3:
DBCC SHOW_STATISTICS('[dbo].[Address]','NC_idx_AddrCity') WITH STAT_HEADER;
GO
DBCC SHOW_STATISTICS(N'[dbo].[Address]', _WA_Sys_00000003_22AA2996)WITH HISTOGRAM;
GO
SELECT City,COUNT(*) FROM dbo.[Address] GROUP BY City ORDER BY City
GO
-- WHAT I LIKE DOING BEFORE UPDATE STATISTICS
DROP TABLE IF EXISTS #AnalyzeStats
GO
CREATE TABLE #AnalyzeStats(
	RANGE_HI_KEY VARCHAR(128),
	RANGE_ROWS INT,
	EQ_ROWS INT,
	DISTINCT_RANGE_ROWS INT,
	AVG_RANGE_ROWS FLOAT
)
DECLARE @StatName VARCHAR(128)='<StatName>'
INSERT INTO #AnalyzeStats
EXECUTE ('DBCC SHOW_STATISTICS(N''[dbo].[Address]'', '+@StatName+')WITH HISTOGRAM')
GO
DECLARE @Fields VARCHAR(1000)
       ,@Table  VARCHAR(128)
SET @Table  ='[dbo].[Address]'
SET @Fields = '[City]'
EXECUTE ('
DECLARE @Fields VARCHAR(1000)
       ,@Table  VARCHAR(128)

SELECT *,Diff = [Rows] - EQ_ROWS
FROM(
SELECT '+@Fields+',COUNT(*)[Rows]
FROM '+@Table+'
GROUP BY '+@Fields+'
)Cnt 
INNER JOIN #AnalyzeStats
   ON Cnt.'+@Fields+'=RANGE_HI_KEY
  AND Cnt.[Rows]<>EQ_ROWS
  '
)
GO
-- UPDATE STATS
UPDATE STATISTICS dbo.[Address]
GO

SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO


