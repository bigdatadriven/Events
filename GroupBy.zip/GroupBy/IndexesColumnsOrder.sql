SET NOCOUNT ON;
GO
USE master 
GO
DROP DATABASE IF EXISTS [IndexOrder]
GO
CREATE DATABASE [IndexOrder]
GO 

USE [IndexOrder]
GO
DROP TABLE IF EXISTS [Products]
GO
CREATE TABLE [dbo].[Address](
	[AddressLine1] [nvarchar](60) NOT NULL,
	[AddressLine2] [nvarchar](60) NULL,
	[City] [nvarchar](30) NOT NULL,
	[StateProvinceID] [int] NOT NULL,
	[PostalCode] [nvarchar](15) NOT NULL,
	[SpatialLocation] [geography] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
INSERT INTO [dbo].[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2017].[Person].[Address]
GO 10
INSERT INTO [dbo].[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2017].[Person].[Address]
WHERE [city] = 'london'
GO 50
GO
CREATE NONCLUSTERED INDEX [idx_cityStProvIdPostCd] ON [dbo].[Address]
(
	[City] ASC,
	[StateProvinceID] ASC,
	[PostalCode] ASC
) ON [PRIMARY]
GO

SELECT [AddressLine1],[City],[StateProvinceID],[StateProvinceID]
FROM [dbo].[Address]
WHERE [PostalCode] = 'SE1 8HL' AND [StateProvinceID] = 14
GO
/*
USE [IndexOrder]
GO
CREATE NONCLUSTERED INDEX [idx_1]
ON [dbo].[Address] ([StateProvinceID],[PostalCode])
INCLUDE ([AddressLine1],[City])
GO
*/
SELECT * FROM [dbo].[Address] WHERE [city] = 'london'
GO
SELECT COUNT(*) FROM [dbo].[Address] WHERE [city] = 'london'
GO
/*
USE [IndexOrder]
GO
CREATE NONCLUSTERED INDEX [idx_1]
ON [dbo].[Address] ([StateProvinceID],[PostalCode])

GO
*/
GO
SELECT *
FROM [dbo].[Address]
WHERE [StateProvinceID] = 14 AND [PostalCode] = 'SE1 8HL' 
/*
USE [IndexOrder]
GO
CREATE NONCLUSTERED INDEX [idx_2]
ON [dbo].[Address] ([StateProvinceID],[PostalCode])

GO
*/

SELECT *
FROM [dbo].[Address]
WHERE [PostalCode] = 'SE1 8HL'  
/*
USE [IndexOrder]
GO
CREATE NONCLUSTERED INDEX [index_2]
ON [dbo].[Address] ([City],[PostalCode])

GO
*/
SELECT *
FROM [dbo].[Address]
WHERE [StateProvinceID] = 14 
GO
SELECT *
FROM [dbo].[Address]
WHERE city = 'london' AND [StateProvinceID] = 14 AND [PostalCode] = 'SE1 8HL'
GO
SP_HELPINDEX '[dbo].[Address]'
GO
SELECT *
FROM [dbo].[Address]
WHERE [StateProvinceID] = 14  AND [PostalCode] = 'SE1 8HL'AND city = 'london'
GO
SELECT
       SCHEMA_DATA.name AS schema_name,
       TABLE_DATA.name AS table_name,
       INDEX_DATA.name AS index_name,
       STUFF((SELECT  ', ' + COLUMN_DATA_KEY_COLS.name + ' ' + CASE WHEN INDEX_COLUMN_DATA_KEY_COLS.is_descending_key = 1 THEN 'DESC' ELSE 'ASC' END -- Include column order (ASC / DESC)
                FROM    sys.tables AS T
                        INNER JOIN sys.indexes INDEX_DATA_KEY_COLS
                                         ON T.object_id = INDEX_DATA_KEY_COLS.object_id
                        INNER JOIN sys.index_columns INDEX_COLUMN_DATA_KEY_COLS
                                         ON INDEX_DATA_KEY_COLS.object_id = INDEX_COLUMN_DATA_KEY_COLS.object_id
                        AND INDEX_DATA_KEY_COLS.index_id = INDEX_COLUMN_DATA_KEY_COLS.index_id
                        INNER JOIN sys.columns COLUMN_DATA_KEY_COLS
                                         ON T.object_id = COLUMN_DATA_KEY_COLS.object_id
                        AND INDEX_COLUMN_DATA_KEY_COLS.column_id = COLUMN_DATA_KEY_COLS.column_id
                WHERE   INDEX_DATA.object_id = INDEX_DATA_KEY_COLS.object_id
                        AND INDEX_DATA.index_id = INDEX_DATA_KEY_COLS.index_id
                        AND INDEX_COLUMN_DATA_KEY_COLS.is_included_column = 0
                ORDER BY INDEX_COLUMN_DATA_KEY_COLS.key_ordinal
                FOR XML PATH('')), 1, 2, '') AS key_column_list ,
   STUFF(( SELECT  ', ' + COLUMN_DATA_INC_COLS.name
                FROM    sys.tables AS T
                        INNER JOIN sys.indexes INDEX_DATA_INC_COLS
                                         ON T.object_id = INDEX_DATA_INC_COLS.object_id
                        INNER JOIN sys.index_columns INDEX_COLUMN_DATA_INC_COLS
                                         ON INDEX_DATA_INC_COLS.object_id = INDEX_COLUMN_DATA_INC_COLS.object_id
                        AND INDEX_DATA_INC_COLS.index_id = INDEX_COLUMN_DATA_INC_COLS.index_id
                        INNER JOIN sys.columns COLUMN_DATA_INC_COLS
                                         ON T.object_id = COLUMN_DATA_INC_COLS.object_id
                        AND INDEX_COLUMN_DATA_INC_COLS.column_id = COLUMN_DATA_INC_COLS.column_id
                WHERE   INDEX_DATA.object_id = INDEX_DATA_INC_COLS.object_id
                        AND INDEX_DATA.index_id = INDEX_DATA_INC_COLS.index_id
                        AND INDEX_COLUMN_DATA_INC_COLS.is_included_column = 1
                ORDER BY INDEX_COLUMN_DATA_INC_COLS.key_ordinal
                FOR XML PATH('')), 1, 2, '') AS include_column_list,
       INDEX_DATA.is_disabled -- Check if index is disabled before determining which dupe to drop (if applicable)
FROM sys.indexes INDEX_DATA
INNER JOIN sys.tables TABLE_DATA
ON TABLE_DATA.object_id = INDEX_DATA.object_id
INNER JOIN sys.schemas SCHEMA_DATA
ON SCHEMA_DATA.schema_id = TABLE_DATA.schema_id
WHERE TABLE_DATA.is_ms_shipped = 0
AND INDEX_DATA.type_desc IN ('NONCLUSTERED', 'CLUSTERED')