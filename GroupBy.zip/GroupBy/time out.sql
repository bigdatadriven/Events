
--Configure the remote query timeout Server Configuration Option
--The default value for this option is 600, which allows a 10-minute wait
--set the value to 0. A query will wait until it is canceled.
USE AdventureWorks2014 ;
GO
EXEC sp_configure 'remote query timeout', 0 ;
GO
RECONFIGURE ;
GO