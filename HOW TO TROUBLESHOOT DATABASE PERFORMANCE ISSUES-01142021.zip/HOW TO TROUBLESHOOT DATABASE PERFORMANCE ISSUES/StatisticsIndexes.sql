USE master
GO
IF DB_ID('Products') IS NOT NULL
DROP DATABASE [Products]

USE master
GO
CREATE DATABASE [Products]
GO
USE [Products]
GO

CREATE TABLE [dbo].[Address](
	[AddressLine1] [nvarchar](60) NOT NULL,
	[AddressLine2] [nvarchar](60) NULL,
	[City] [nvarchar](30) NOT NULL,
	[StateProvinceID] [int] NOT NULL,
	[PostalCode] [nvarchar](15) NOT NULL,
	[SpatialLocation] [geography] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
INSERT INTO products.dbo.[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2019].[Person].[Address]
GO
--no statistics
SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO

--this query, will automatically create statistics
SELECT * FROM dbo.[Address] WHERE city='London'
GO

SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO

DBCC SHOW_STATISTICS(N'[dbo].[Address]', <statistics name>)
DBCC SHOW_STATISTICS(N'[dbo].[Address]', <statistics name>)WITH HISTOGRAM
GO
SELECT [City] , COUNT(*) FROM [AdventureWorks2019].[Person].[Address] GROUP BY [City] ORDER BY [City]
GO

CREATE INDEX NC_idx_AddrCity on dbo.[Address](city)
GO

DBCC SHOW_STATISTICS('[dbo].[Address]','NC_idx_AddrCity') WITH STAT_HEADER;
GO

SELECT COUNT(*) from dbo.[Address]
GO
-- THE OTHER WAY
SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO
-- 832
INSERT INTO products.dbo.[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2019].[Person].[Address]
WHERE City in('London','Paris')
GO
-- STEP 1:
-- This is not really a good way to see if statistics is update to date
DBCC SHOW_STATISTICS('[dbo].[Address]','NC_idx_AddrCity') WITH STAT_HEADER;
GO
DBCC SHOW_STATISTICS(N'[dbo].[Address]', 'NC_idx_AddrCity')WITH HISTOGRAM;
GO
SELECT City,COUNT(*) FROM dbo.[Address] WHERE City in('London','Paris') GROUP BY City ORDER BY City
GO
-- STEP 2:
SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO
-- STEP 3:
DBCC SHOW_STATISTICS('[dbo].[Address]','NC_idx_AddrCity') WITH STAT_HEADER;
GO
DBCC SHOW_STATISTICS(N'[dbo].[Address]', <statistics name>)WITH HISTOGRAM;
GO
SELECT City,COUNT(*) FROM dbo.[Address] GROUP BY City ORDER BY City
GO

UPDATE STATISTICS dbo.[Address]
GO

SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'[dbo].[Address]');
GO


