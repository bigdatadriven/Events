USE master
GO
IF DB_ID('Slowness') IS NOT NULL
DROP DATABASE [Slowness]
GO
CREATE DATABASE [Slowness]
GO
USE [Slowness]
GO
IF OBJECT_ID('Address') IS  NOT NULL 
DROP TABLE [Address]
GO
CREATE TABLE [dbo].[Address](
	[AddressLine1] [nvarchar](60) NOT NULL,
	[AddressLine2] [nvarchar](60) NULL,
	[City] [nvarchar](30) NOT NULL,
	[StateProvinceID] [int] NOT NULL,
	[PostalCode] [nvarchar](15) NOT NULL,
	[SpatialLocation] [geography] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
INSERT INTO dbo.[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2019].[Person].[Address]
GO
CREATE INDEX ixd_city ON [dbo].[Address](City);
GO

--1: difference between open trasaction and blocking
USE [Slowness]
GO
SELECT * FROM [dbo].[Address]  WHERE City = 'London'
--step 2
USE [Slowness]
GO
BEGIN TRAN
UPDATE A
SET AddressLine1 = '255 Irving Street'
FROM [dbo].[Address] AS A 
WHERE City = 'London'

--open a new session and run this select statement
USE [Slowness]
GO
SELECT * FROM [dbo].[Address]  WHERE City = 'London'

--open a new session and run this select statement
BEGIN TRAN
UPDATE p
SET PersonType='SP'
FROM [AdventureWorks2019].[Person].[Person] p where PersonType='SP'

--use step 1 session for this below query
SELECT * FROM [AdventureWorks2019].[Person].[Person] p where PersonType='SP'


