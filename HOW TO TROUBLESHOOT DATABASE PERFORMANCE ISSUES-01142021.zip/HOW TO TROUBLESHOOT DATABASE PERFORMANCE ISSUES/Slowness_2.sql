USE master
GO
IF DB_ID('Slowness') IS NOT NULL
DROP DATABASE [Slowness]
GO
CREATE DATABASE [Slowness]
GO
USE [Slowness]
GO
IF OBJECT_ID('Address') IS  NOT NULL 
DROP TABLE [Address]
GO
CREATE TABLE [dbo].[Address](
	[AddressLine1] [nvarchar](60) NOT NULL,
	[AddressLine2] [nvarchar](60) NULL,
	[City] [nvarchar](30) NOT NULL,
	[StateProvinceID] [int] NOT NULL,
	[PostalCode] [nvarchar](15) NOT NULL,
	[SpatialLocation] [geography] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
INSERT INTO dbo.[Address]
SELECT [AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[SpatialLocation]
FROM [AdventureWorks2019].[Person].[Address]
GO
CREATE INDEX ixd_city ON [dbo].[Address](City);
GO
CREATE PROC usp_UpdateAddresss
@City VARCHAR(50)
AS
BEGIN
	IF EXISTS(SELECT 1 FROM dbo.[Address] WHERE City = @City)
		BEGIN
			UPDATE dbo.[Address] SET [AddressLine1] = '255 Irving Street'
			WHERE City = @City;
			INSERT INTO dbo.[Address]
			SELECT *
			FROM dbo.[Address]
			--WHERE City = @City; 
		END
END
--EXEC sp_depends @objname = N'[dbo].[usp_UpdateAddresss]'
DECLARE @sp nvarchar(100)
SET @sp = N'[dbo].[usp_UpdateAddresss]' 
-- Objects on which the stored procedure @sp depends
SELECT 
   DISTINCT 'SELECT
OBJECT_NAME([sp].[object_id]) AS "Table",
[sp].[stats_id] AS "Statistic ID",
[s].[name] AS "Statistic",
[sp].[last_updated] AS "Last Updated",
[sp].[rows],
[sp].[rows_sampled],
[sp].[unfiltered_rows],
[sp].[modification_counter] AS "Modifications"
FROM [sys].[stats] AS [s]
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]
WHERE [s].[object_id] = OBJECT_ID(N'''+referenced_schema_name+'.'+ referenced_entity_name+''');',referenced_schema_name, referenced_entity_name,is_selected,is_select_all,is_updated,is_insert_all,is_incomplete,is_all_columns_found
FROM 
    sys.dm_sql_referenced_entities(@sp, 'OBJECT')rf
WHERE rf.referenced_entity_name IN(SELECT name FROM sys.tables)
GO
EXECUTE dbo.usp_UpdateAddresss 'London'
GO
-- ANALYZING
SELECT COUNT(1) FROM dbo.[Address]
GO
SELECT  OBJECT_NAME([sp].[object_id]) AS "Table"
     ,  [sp].[stats_id] AS "Statistic ID"
	 ,  [s].[name] AS "Statistic"
	 ,  [sp].[last_updated] AS "Last Updated"
	 ,  [sp].[rows],  [sp].[rows_sampled]
	 ,  [sp].[unfiltered_rows]
	 ,  [sp].[modification_counter] AS "Modifications"  
FROM [sys].[stats] AS [s]  
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]  
WHERE [s].[object_id] = OBJECT_ID(N'dbo.Address');
GO
UPDATE STATISTICS dbo.Address
GO
SELECT  OBJECT_NAME([sp].[object_id]) AS "Table"
     ,  [sp].[stats_id] AS "Statistic ID"
	 ,  [s].[name] AS "Statistic"
	 ,  [sp].[last_updated] AS "Last Updated"
	 ,  [sp].[rows],  [sp].[rows_sampled]
	 ,  [sp].[unfiltered_rows]
	 ,  [sp].[modification_counter] AS "Modifications"  
FROM [sys].[stats] AS [s]  
OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id]) AS [sp]  
WHERE [s].[object_id] = OBJECT_ID(N'dbo.Address');
GO