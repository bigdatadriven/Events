
--look for any open trnsaction
select spid
      ,blocked
	  ,lastwaittype
	  ,db_name(dbid) as'DBName'
	  ,login_time
	  ,last_batch,open_tran
	  ,program_name
	  ,cmd
	  ,loginame
	  ,hostname
	  ,status  
from sys.sysprocesses where blocked>0
-- CHECK FOR OPEN TRANSACTIONS
SELECT spid
      ,blocked
	  ,lastwaittype
	  ,db_name(dbid) as'DBName'
	  ,login_time
	  ,last_batch
	  ,open_tran
	  ,program_name
	  ,cmd
	  ,loginame
	  ,hostname
	  ,status  
FROM sys.sysprocesses 
WHERE open_tran>0

--Query to Find Blocked or Waiting Tasks
--http://sqlmag.com/database-performance-tuning/troubleshooting-common-sql-server-problems

SELECT
  w.session_id,
  w.wait_duration_ms,
  w.wait_type,
  w.blocking_session_id,
  s.[host_name],
  r.command,
  r.percent_complete,
  r.cpu_time,
  r.total_elapsed_time,
  r.reads,
  r.writes,
  r.logical_reads,
  r.row_count,
  q.[text]
  ,q.dbid
  ,p.query_plan
  ,r.plan_handle
FROM
  sys.dm_os_waiting_tasks w
  INNER JOIN sys.dm_exec_sessions s
    ON w.session_id = s.session_id
  INNER JOIN sys.dm_exec_requests r
    ON s.session_id = r.session_id
  CROSS APPLY sys.dm_exec_sql_text(r.plan_handle) q
  CROSS APPLY sys.dm_exec_query_plan(r.plan_handle) p
WHERE
  w.session_id > 50--= 
  AND w.wait_type NOT IN
  ('DBMIRROR_DBM_EVENT','ASYNC_NETWORK_IO'
    /* + add your own here*/)

--SELECT spid,blocked,lastwaittype,db_name(dbid) as'DBName',login_time,last_batch,open_tran,program_name,cmd,loginame,hostname,loginame,status 
--FROM sys.sysprocesses where spid in(55,56)

--query statement for 54
 SELECT spid,blocked,lastwaittype,db_name(p.dbid) as'DBName',login_time,last_batch,open_tran,program_name,cmd,loginame,hostname,loginame,text,status 
 FROM sys.sysprocesses  p  
 CROSS APPLY sys.dm_exec_sql_text(sql_handle) q  
 WHERE spid IN(55,57)

--Use this for the sec update
select spid,blocked,lastwaittype,db_name(p.dbid) as'DBName',login_time,last_batch,open_tran,program_name,cmd,loginame,hostname,loginame,text ,status
from sys.sysprocesses  p  
CROSS APPLY sys.dm_exec_sql_text(sql_handle) q  
WHERE blocked>0 OR open_tran>0
  ORDER BY last_batch

 
 /*
 dbcc inputbuffer(51)

CHECKPOINT

SELECT es.session_id, ib.event_info
FROM sys.dm_exec_sessions AS es
CROSS APPLY sys.dm_exec_input_buffer(es.session_id, NULL) AS ib
WHERE es.session_id > 50;
GO
 */

