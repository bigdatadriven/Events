DROP TABLE IF EXISTS #DemoTempTable
GO




CREATE TABLE #DemoTempTable(
     FirstName VARCHAR(50)
    ,LastName VARCHAR(50)
    ,[Address] VARCHAR(512)
)
GO





INSERT INTO #DemoTempTable
SELECT 'Jean','Joseph','4933 Duke Lane, Red Bank, New Jersey, 07701' UNION 
SELECT 'Garallard','Babby','4148 Kidd Avenue, Mekoryuk, Alaska, 99630' UNION
SELECT 'Bobby','Daniel','1596 Diamond Cove, Providence, Rhode Island, 02903'
GO




/* 
	Break it down to AddressName, CityName, StateName, ZipCode
*/
SELECT * FROM #DemoTempTable
GO





SELECT [FirstName]
      ,[LastName]
      ,[AddressName] = PARSENAME( REPLACE( [Address], ',', '.'), 4)
      ,[CityName]    = PARSENAME( REPLACE( [Address], ',', '.'), 3)
      ,[StateName]   = PARSENAME( REPLACE( [Address], ',', '.'), 2)
      ,[ZipCode]     = PARSENAME( REPLACE( [Address], ',', '.'), 1)
FROM #DemoTempTable
GO






/******************************************************************************* 
	 STRING_SPLIT ( string , separator [ , enable_ordinal ] )

	 Your application accept people to have four phone number
	 ([Home],[Mobile],[WorkPhone],[ContactNumber])
	 but the data is not uniform 
*/
USE DataDrivenCommunity
GO
IF OBJECT_ID('tempdb..#EmpPhoneNumberList') IS NOT NULL
DROP TABLE tempdb..#EmpPhoneNumberList;
GO

CREATE TABLE #EmpPhoneNumberList
(EmpId INT IDENTITY(1,1),
EmpPhoneNo VARCHAR(100)
)
GO




INSERT INTO #EmpPhoneNumberList
(EmpPhoneNo)
VALUES
('789-879-8797,898-989-3333,862-582-1114,598-263-8741'),
('698-582-7456,968-632-5749'),
('973-014-9658,215-985-4715,400-589-6582,900-358-9524'),
('356-985-5784')
GO


-- [Home],[Mobile],[WorkPhone],[ContactNumber]
SELECT *
FROM dbo.EmpPhoneNumberList
GO











SELECT  EmpId,
		EmpPhoneNo, 
		ISNULL([Phone_1],'') AS [Home], 
		ISNULL([Phone_2],'') AS [Mobile], 
		ISNULL([Phone_3],'') AS [WorkPhone], 
		ISNULL([Phone_4],'') AS [ContactNumber] 
FROM ( 
 SELECT EmpId, 
 EmpPhoneNo, 
 'Phone_'+ CAST(ROW_NUMBER()OVER(PARTITION BY EmpId ORDER BY EmpId) AS VARCHAR) AS Col
 ,Split.value 
 FROM dbo.EmpPhoneNumberList AS Emp 
 CROSS APPLY STRING_SPLIT(EmpPhoneNo,',') AS Split 
 ) AS tbl
Pivot (Max(Value) FOR Col IN ([Phone_1],[Phone_2],[Phone_3],[Phone_4])
) AS Pvt
GO






/************************************************************************************************************************
	STRING_AGG: is an aggregate function that takes all expressions from rows and concatenates them into a single string

	STRING_AGG ( expression, separator ) [ <order_clause> ]

	<order_clause> ::=   

		WITHIN GROUP ( ORDER BY <order_by_expression_list> [ ASC | DESC ] )
*/

DROP TABLE IF EXISTS [#PersonTestTable]
GO
CREATE TABLE [#PersonTestTable](
    [FirstName] [varchar](400) NULL,
    [LastName] [varchar](400) NULL,
    [Mail] [varchar](100) NULL,
    Country [varchar](100) NULL,
    Age [int] NULL
    
) 
GO

SET NOCOUNT ON;
GO

INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Lawrence',N'Williams',N'uhynb.ndlguey@vtq.org',N'U.S.A.',21)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Gilbert',N'Miller',N'loiysr.jeoni@wptho.co',N'U.S.A.',53)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Salvador',N'Rodriguez',N'tjybsrvg.rswed@uan.org',N'Russia',46)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Ernest',N'Jones',N'psxkrzf.jgcmc@pfdknl.org',N'U.S.A.',48)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Jerome',N'Garcia',NULL,N'Russia',46)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Roland',N'Smith','xpdek.qpl@kpl.com',N'U.S.A. ',35)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Stella',N'Johnson',N'qllyoxgr.jsntdty@pzwm.org',N'Russia',24)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Aria',N'Anderson',N'sjgnz.voyyc@cvjg.com',N'Brazil ',25)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Edward',N'Martinez','pokjs.oas@mex.com',N'Mexico ',27)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Nicholas',N'Brown',N'wpfiki.hembt@uww.co',N'Russia ',43)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Ray',N'Wilson',NULL,N'Russia',41)
INSERT INTO [#PersonTestTable] ([FirstName],[LastName],[Mail],[Country],[Age]) VALUES (N'Jorge',N'Davis',N'bhlji.zwngl@kle.com',N'Russia ',49)
GO

SELECT *
FROM [#PersonTestTable]
ORDER BY Country

/*
	Grouping all emails by countries 
*/

SELECT Country,Mail
FROM [#PersonTestTable]
--WHERE country='Russia' 
GROUP BY Country, Mail



SELECT Country
      ,STRING_AGG(Mail,', ')  WITHIN GROUP ( ORDER BY FirstName ASC)  ASEmailByCountry 
FROM [#PersonTestTable]
GROUP BY Country
ORDER BY Country ASC
GO





/*******************************************************************************************
	FORMAT vs REPLICATE
*/
DROP TABLE IF EXISTS #Contacts
GO



CREATE TABLE #Contacts(
    FullName  VARCHAR(50),
    registration_code VARCHAR(9)
)
GO






INSERT INTO #Contacts
SELECT 'Jean Joseph','001578529' UNION 
SELECT 'Jean Joseph','524' UNION
SELECT 'Jean Joseph','9' UNION
SELECT 'Jean Joseph','00029'





SELECT *
FROM #Contacts;
GO






SELECT  FullName,
        CONCAT(REPLICATE('0', 9 -LEN(registration_code)), registration_code) AS registration_code
FROM #Contacts;
GO






SET NOCOUNT ON;
GO

SELECT FullName,
       FORMAT(CAST(registration_code AS INT), '000000000') AS registration_code
FROM #Contacts;
GO





/********************************************************************************
	NOT ALL RESHAPING IS EASY TO FIX
*/



/*
Carriage Return, Line Feed & Tab in a string
We might require inserting a carriage return or line break while working with the string data. 
In SQL Server, we can use the CHAR function with ASCII number code. 
We can use the following ASCII codes in SQL Server:

Char(10) � New Line / Line Break
Char(13) � Carriage Return
Char(9) � Tab

Let�s explore these ASCII codes with CHAR functions with examples.
*/


/*
    Suppose we have a string that contains a month�s name. We use a comma to separate the name of the month.
    Execute this query in SSMS and view output in Result to text (short cut key CTRL + T) format:
*/
/*
	REMOVE CARRIAGE RETURN, LINE FEED & TAB IN A STRING
*/

/*
    Let's consider we have this dataset

    Char(10) � New Line / Line Break
    Char(13) � Carriage Return
    Char(9) � Tab    
*/

SET NOCOUNT ON;
GO

DROP TABLE IF EXISTS [#EmployeeData]
GO

CREATE TABLE [#EmployeeData]
([EmpID]     INT IDENTITY(1, 1), 
 [FirstName] NVARCHAR(20), 
 [LastName]  NVARCHAR(20), 
 [Address]   NVARCHAR(100)
);

INSERT INTO [#EmployeeData]
(FirstName, 
 LastName, 
 Address
)
VALUES
(N'Jean',
N'Joseph',
N'4933 
Duke Lane, 
Red Bank, 
New Jersey, 07701'
);
GO






SELECT FirstName, 
 LastName
 ,REPLACE([Address],' ','') AS FirstReplace
 --,REPLACE([Address],SPACE(1),'') AS SecondReplace
FROM [#EmployeeData]
GO








SET NOCOUNT ON;
GO

SELECT EmpID, FirstName, lastName, 
REPLACE(Address,CHAR(13)+CHAR(10),' ') as address 
FROM [#EmployeeData]
GO






