USE [DataDrivenCommunity]
GO





--SAME DATA SET
SELECT *
FROM [DataDrivenCommunity].[dbo].[Products]
GO






WITH CTE AS(
SELECT [SalesData]
      ,VALUE
	  ,ROW_NUMBER()OVER(PARTITION BY [SalesData] ORDER BY [SalesData]) AS RowNumber
FROM [DataDrivenCommunity].[dbo].[Products]
CROSS APPLY STRING_SPLIT([SalesData],',')
)
SELECT  [1] AS OrderNumber
       ,[2] AS Region
	   ,[3] AS SaleRep
	   ,[4] AS Productname
	   ,[5] AS Units
	   ,[6] AS Unit_Cost
	   ,[7] AS Total
FROM CTE 
PIVOT (MAX(VALUE)
FOR RowNumber IN ([1],[2],[3],[4],[5],[6],[7])) AS PVT
