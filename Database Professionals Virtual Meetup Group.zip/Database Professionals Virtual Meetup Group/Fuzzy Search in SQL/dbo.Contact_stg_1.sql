SET NOCOUNT ON
GO
/*
	CLEAN DATA
*/
IF DB_ID('DataDrivenCommunity') IS NULL
	BEGIN
		CREATE DATABASE DataDrivenCommunity
	END
GO

USE DataDrivenCommunity
GO

IF OBJECT_ID('dbo.Contact_stg') IS NOT NULL
DROP TABLE dbo.Contact_stg;
GO

BEGIN
	CREATE TABLE dbo.Contact_stg(
		 FirstName VARCHAR(50)
		,LastName  VARCHAR(50)		
		,Email     VARCHAR(128)
		,PhoneNumber VARCHAR(30)
	)		
	INSERT INTO Contact_stg
	SELECT 'Benjamin','Sheriff','Benjamin.Sherrif@gmail.com','500-548-9080' UNION ALL
	SELECT 'Cocoa','Fairchil','Cocoa.Fairchild@gmail.com','600-755-6528' UNION ALL
	SELECT 'Danuzio','Pinheiro','Danuzio.Pinherio@gmail.com','500-548-7541' UNION ALL
	SELECT 'Jeff','Voight','Jeff.Voigt@gmail.com','862-658-9080' UNION ALL
	SELECT 'Marie','Prendergast','Marie.Prendergrast@gmail.com','300-245-8596' UNION ALL
	SELECT 'Michael','Heinrich','Michael.Heinricy@gmail.com','201-300-8574' UNION ALL
	SELECT 'Nghia','Le','Nghia.Lee@gmail.com','215-987-0001' UNION ALL
	SELECT 'Leonardo','Madrigal','Leonardo.MadrigalDelValle@gmail.com','785-500-2220' UNION ALL
	SELECT 'Yolanda','Balcazar','Yolanda.Balcazar-Rodriguez@gmail.com','568-412-8745' UNION ALL
	SELECT 'J','Garcia Martinez','J.Garcia-Martinez@gmail.com','862-963-2580' UNION ALL
	SELECT 'Lauren','Lord � Tuley','Lauren.Lord-Tuley@gmail.com','600-815-2684' UNION ALL
	SELECT 'Virginia','Pulley Alberts','Virginia.Pulley-Alberts@gmail.com','501-321-8012' UNION ALL
	SELECT 'Connie','Marks','Connie.MarksIv@gmail.com','500-548-8147' UNION ALL
	SELECT 'Daniel','Ladd','Daniel.Ladd@gmail.com','900-110-1410' UNION ALL
	SELECT 'Rodrigo','Delgado','Rodrigo.Delgado@gmail.com','951-503-3025' UNION ALL
	SELECT 'Thomas','Griffin','Thomas.Griffin@gmail.com','500-002-1123' UNION ALL
	SELECT 'Jean','Joseph','Jean.Joseph@gmail.com','862-021-2510' UNION ALL
	SELECT 'Donnielllo','Gpraellorrd','Jeanne.Garellard@gmail.com','635-172-9236' UNION ALL
	SELECT 'Wayne','Nance','Wayne.Nance@gmail.com','500-412-9080' 
END
GO

SELECT * FROM dbo.Contact_stg