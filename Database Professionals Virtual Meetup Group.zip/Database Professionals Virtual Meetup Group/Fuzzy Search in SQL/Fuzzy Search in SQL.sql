/*
	Finding Similar Type of Names | Fuzzy Search in SQL


	Problem Statement :
	Finding all kind of error types that described in the below table e.g. 
	Spelling Mistake, Incomplete Name, Formatting Issue, Suffix Missing.


	Fuzzy Search :
	A technique of finding the strings that match a pattern approximately (rather than exactly).

*/

/*
	SOUNDEX Compatibility
	In previous versions of SQL Server, the SOUNDEX function applied a subset of the SOUNDEX rules. 
	Under database compatibility level 110 or higher, SQL Server applies a more complete set of the rules.

	After upgrading to compatibility level 110 or higher, you may need to rebuild the indexes, 
	heaps, or CHECK constraints that use the SOUNDEX function.

	A heap that contains a persisted computed column defined with SOUNDEX cannot be queried until 
	the heap is rebuilt by running the statement ALTER TABLE <table> REBUILD.

	CHECK constraints defined with SOUNDEX are disabled upon upgrade. To enable the constraint, 
	run the statement ALTER TABLE <table> WITH CHECK CHECK CONSTRAINT ALL.

	Indexes (including indexed views) that contain a persisted computed column defined with SOUNDEX 
	cannot be queried until the index is rebuilt by running the statement ALTER INDEX ALL ON <object> REBUILD.

	SOUNDEX ( character_expression )  
*/

-- Example: Using SOUNDEX  
SELECT SOUNDEX ('Smith'), SOUNDEX ('Smythe');

USE [DataDrivenCommunity]
GO

SELECT [EmpId]
      ,[FirstName]
      ,[LastName]
  FROM [dbo].[ContactLookup]

GO

SELECT [FirstName]
      ,[LastName]
	  ,PhoneNumber
      ,[Email]
  FROM [dbo].[Contact_stg]
GO



SELECT LKUP.[EmpId] AS LKUP_Id
      ,LKUP.[FirstName] AS LKUP_FirstName
	  ,LKUP.[LastName] AS LKUP_LastName
	  ,STG.[FirstName]
      ,STG.[LastName]
	  ,STG.PhoneNumber
      ,STG.[Email]
FROM [dbo].[ContactLookup] AS LKUP
INNER JOIN [dbo].[Contact_stg] AS STG
ON (
	SOUNDEX(LKUP.[FirstName])=SOUNDEX(STG.[FirstName])
	AND
	SOUNDEX(LKUP.[LastName])=SOUNDEX(STG.[LastName])
   )



INSERT INTO [dbo].[Contact]
SELECT LKUP.[EmpId] AS LKUP_Id
      ,LKUP.[FirstName] AS LKUP_FirstName
	  ,LKUP.[LastName] AS LKUP_LastName
	  ,STG.PhoneNumber
      ,STG.[Email]
FROM [dbo].[ContactLookup] AS LKUP
INNER JOIN [dbo].[Contact_stg] AS STG
ON (
	SOUNDEX(LKUP.[FirstName])=SOUNDEX(STG.[FirstName])
	AND
	SOUNDEX(LKUP.[LastName])=SOUNDEX(STG.[LastName])
   )
GO


SELECT * FROM [dbo].[Contact]

/*
	DIFFERENCE (Transact-SQL)

	Arguments
	character_expression
	An alphanumeric expression of character data. character_expression can be a constant, variable, or column.

	Return Types
	int

	Remarks
	DIFFERENCE compares two different SOUNDEX values, and returns an integer value. 
	This value measures the degree that the SOUNDEX values match, on a scale of 0 to 4. 
	A value of 0 indicates weak or no similarity between the SOUNDEX values; 4 indicates strongly similar, 
	or even identically matching, SOUNDEX values.

	DIFFERENCE and SOUNDEX have collation sensitivity.

	Examples
	The first part of this example compares the SOUNDEX values of two very similar strings. 
	For a Latin1_General collation, DIFFERENCE returns a value of 4. The second part of the 
	example compares the SOUNDEX values for two very different strings, and for a Latin1_General collation, 
	DIFFERENCE returns a value of 0.

 
*/
-- Returns a DIFFERENCE value of 4, the least possible difference.  
SELECT SOUNDEX('Green'), SOUNDEX('Greene'), DIFFERENCE('Green','Greene');  
GO  
-- Returns a DIFFERENCE value of 0, the highest possible difference.  
SELECT SOUNDEX('Blotchet-Halls'), SOUNDEX('Greene'), DIFFERENCE('Blotchet-Halls', 'Greene');  
GO 



SELECT LKUP.[EmpId] AS LKUP_Id
      ,LKUP.[FirstName] AS LKUP_FirstName
	  ,LKUP.[LastName] AS LKUP_LastName
      ,STG.[Email]
	  ,DIFFERENCE(LKUP.[FirstName],STG.[FirstName])
FROM [dbo].[ContactLookup] AS LKUP
INNER JOIN [dbo].[Contact_stg] AS STG
ON (
	DIFFERENCE(LKUP.[FirstName],STG.[FirstName])=4
	AND
	DIFFERENCE(LKUP.[LastName],STG.[LastName])=4
   )
ORDER BY LKUP.[EmpId]


WITH FuzzyMatching AS
(
	SELECT LKUP.[EmpId] AS LKUP_Id
		  ,LKUP.[FirstName] AS LKUP_FirstName
		  ,LKUP.[LastName] AS LKUP_LastName
		  ,STG.[FirstName]
		  ,STG.[LastName]
		  ,STG.[Email]
		  ,CASE WHEN DIFFERENCE(LKUP.[FirstName],STG.[FirstName])=4 THEN LKUP.[FirstName] END AS FirstName_Revisit
		  ,CASE WHEN DIFFERENCE(LKUP.[LastName],STG.[LastName])=4 THEN LKUP.[LastName] END AS LastName_Revisit
	FROM [dbo].[ContactLookup] AS LKUP
	INNER JOIN [dbo].[Contact_stg] AS STG
	ON (
		DIFFERENCE(LKUP.[FirstName],STG.[FirstName])>=3
		AND
		DIFFERENCE(LKUP.[LastName],STG.[LastName])>=3
	   )
)
SELECT *
FROM FuzzyMatching
WHERE (FirstName_Revisit IS NULL OR LastName_Revisit IS NULL)