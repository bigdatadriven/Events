SET NOCOUNT ON
GO
/*
	CLEAN DATA
*/
IF DB_ID('DataDrivenCommunity') IS NULL
	BEGIN
		CREATE DATABASE DataDrivenCommunity
	END
GO

USE DataDrivenCommunity
GO

IF OBJECT_ID('dbo.Contact') IS NOT NULL
DROP TABLE dbo.Contact
GO

BEGIN
	CREATE TABLE dbo.Contact(
			EmpId     INT
		,FirstName VARCHAR(50)
		,LastName  VARCHAR(50)
		,PhoneNumber VARCHAR(50)
		,Email     VARCHAR(128)
	)
END
GO

SELECT * FROM dbo.Contact