SET NOCOUNT ON
GO
/*
	CLEAN DATA
*/
IF DB_ID('DataDrivenCommunity') IS NULL
	BEGIN
		CREATE DATABASE DataDrivenCommunity
	END
GO

USE DataDrivenCommunity
GO

IF OBJECT_ID('dbo.ContactLookup') IS NOT NULL
DROP TABLE dbo.ContactLookup
GO

BEGIN
	CREATE TABLE dbo.ContactLookup(
		 EmpId     INT
		,FirstName VARCHAR(50)
		,LastName  VARCHAR(50)
	)	
	INSERT INTO ContactLookup
	SELECT 2000 AS EmpId,'Benjamin' AS FirstName,'Sherrif' AS LastName UNION ALL
	SELECT 2001,'Cocoa','Fairchild' UNION ALL
	SELECT 2002,'Danuzio','Pinherio' UNION ALL
	SELECT 2003,'Jeff','Voigt' UNION ALL
	SELECT 2004,'Marie','Prendergrast' UNION ALL
	SELECT 2005,'Michael','Heinricy' UNION ALL
	SELECT 2006,'Nghia','Lee' UNION ALL
	SELECT 2007,'Leonardo','Madrigal Del Valle' UNION ALL
	SELECT 2008,'Yolanda','Balcazar-Rodriguez' UNION ALL
	SELECT 2009,'J','Garcia-Martinez' UNION ALL
	SELECT 2010,'Lauren','Lord-Tuley' UNION ALL
	SELECT 2011,'Virginia','Pulley-Alberts' UNION ALL
	SELECT 2012,'Connie','Marks Iv' UNION ALL
	SELECT 2013,'Daniel','Ladd Jr' UNION ALL
	SELECT 2014,'Rodrigo','Delgado Jr' UNION ALL
	SELECT 2015,'Thomas','Griffin Iii' UNION ALL
	SELECT 2016,'Wayne','Nance Ii' UNION ALL
	SELECT 2017,'Wayne','Nance Ii' UNION ALL
	SELECT 2018,'Daniello','Garellard' --UNION ALL
END
GO
SELECT * FROM dbo.ContactLookup