/********************************************************************************************
	RANGE vs ROWS

	ROWS are in memory
	RANGE is in Tempdb and Range is the default

	Default AGGREGATE FUNCTIONS sometimes give wrong
		RANGE: can give you some odds result set and also display duplicated values
*/
SELECT TOP 5
	   PurchaseOrderID,
       PurchaseOrderDetailID,
       ProductID,
       LineTotal,
       SUM(LineTotal) OVER (ORDER BY PurchaseOrderId) AS TotalDue,
	   SUM(LineTotal) OVER (ORDER BY PurchaseOrderId Range UNBOUNDED PRECEDING) AS TotalDue
FROM AdventureWorks2019.Purchasing.PurchaseOrderDetail
ORDER BY PurchaseOrderId
GO


/*
    ROWS UNBOUNDED PRECEDING: will give us a perfect running total
	Rows is in memory
*/
SELECT TOP 5
	   PurchaseOrderID,
       PurchaseOrderDetailID,
	   ProductID,
	   LineTotal,
	   SUM(LineTotal) OVER (ORDER BY PurchaseOrderId ROWS UNBOUNDED PRECEDING) AS TotalDue
FROM AdventureWorks2019.Purchasing.PurchaseOrderDetail
ORDER BY PurchaseOrderId









--The data types varchar and varbinary are incompatible in the add operator.
-- get the first 5 and last 6 characters
DECLARE @String VARBINARY(50)

SELECT @String=0x4A65616E204A6F73657068

SELECT '''' + @String + '''' 
GO





DECLARE @String VARBINARY(50), @ConvertString VARCHAR(50)

SELECT @String=0x4A65616E204A6F73657068
SELECT LEFT(CONVERT(VARCHAR(50),@String),5)
      ,CAST(LEFT(CONVERT(VARCHAR(50),@String),5) AS VARCHAR(50))
	  ,RIGHT(CONVERT(VARCHAR(50),@String),6)
      ,CAST(RIGHT(CONVERT(VARCHAR(50),@String),6) AS VARCHAR(50))
GO













/*
-- CAST Syntax:  
CAST ( expression AS data_type [ ( length ) ] )  
  
-- CONVERT Syntax:  
CONVERT ( data_type [ ( length ) ] , expression [ , style ] )
*/

DECLARE @String VARBINARY(50), @ConvertString VARCHAR(50)
--sTYLE = 1
SELECT @String=0x4A65616E204A6F73657068
SELECT LEFT(CONVERT(VARCHAR(50),@String,0),5)
      ,CAST(LEFT(CONVERT(VARCHAR(50),@String,1),5) AS VARCHAR(50))
	  ,RIGHT(CONVERT(VARCHAR(50),@String,0),6)
      ,CAST(RIGHT(CONVERT(VARCHAR(50),@String,1),6) AS VARCHAR(50))





--Extract File Name.
/*
    REVERSE:   REVERSE  (  string_expression  )
    SUBSTRING: SUBSTRING ( expression ,start , length )
    CHARINDEX: CHARINDEX ( expressionToFind , expressionToSearch [ , start_location ] ) 

    Requirement: Extract the file name and extension
*/
SET NOCOUNT ON;
GO

DECLARE @String VARCHAR(60)

SET @String = '\\SVR\D$\FileDirctory\njsqlcentralsqlusergroup.demo'

SELECT @String;

SELECT REVERSE(@String);

SELECT SUBSTRING(REVERSE(@String),1,CHARINDEX('\',REVERSE(@String))-1);

SELECT REVERSE(SUBSTRING(REVERSE(@String),1,CHARINDEX('\',REVERSE(@String))-1));









/*
	TRIM ( [ LEADING | TRAILING | BOTH ] [characters FROM ] string )
	You will need your database compatibility level set to 160 to use the LEADING, TRAILING, or BOTH keywords.

	https://learn.microsoft.com/en-us/sql/t-sql/functions/trim-transact-sql?view=sql-server-ver16
*/
SELECT TRIM('#! ' FROM '    #Data Driven Community!    ') AS [TrimmedString]       
	   ,REPLACE(REPLACE(TRIM('    #Data Driven Community!    '),'#',''),'!','') AS [ReplaceTrim]
	   ,REPLACE(REPLACE(LTRIM(RTRIM('    #Data Driven Community!    ')),'#',''),'!','') AS [ReplaceLTrimRTrim]
GO























/**********************************************************************************************************
	TRANSLATE vs REPLACE


	TRANSLATE ( inputString, characters, translations )

	REPLACE ( string_expression , string_pattern , string_replacement )

*/
SELECT 
    REPLACE(REPLACE(REPLACE(REPLACE('2*[3+4]/{7-2}','[','('), ']', ')'), '{', '('), '}', ')') AS [Replace],
    TRANSLATE('2*[3+4]/{7-2}', '[]{}', '()()') AS [Translate];


/* Remarks

	TRANSLATE will return an error if characters and translations expressions have different lengths. 
	TRANSLATE will return NULL if any of the arguments are NULL.

	The second and third arguments of the TRANSLATE built-in function must contain an equal number of characters.

	The behavior of the TRANSLATE function is similar to using multiple REPLACE functions. 
	TRANSLATE doesn't, however, replace any individual character in inputString more than once. 
	A single value in the characters parameter can replace multiple characters in inputString.

	Ref: https://learn.microsoft.com/en-us/sql/t-sql/functions/translate-transact-sql?view=sql-server-ver16
*/
SET NOCOUNT ON;
GO

DECLARE @String VARCHAR(80)

SET @String = 'Welcome To Data Driven Community User Group'

SELECT REPLACE(@String,'Data Driven Community','New England SQL Server')

SELECT TRANSLATE(@String,'Data Driven Community','New England SQL Serve') --SELECT LEN('Data Driven Community'),LEN('New England SQL Serve')
	-- https://learn.microsoft.com/en-us/sql/t-sql/functions/translate-transact-sql?view=sql-server-ver16
SELECT TRANSLATE(@String,'Data Driven Community','New England SQL Server User Group')--dif len()
GO




/**********************************************************************************************

*/
DECLARE @ft1 FLOAT = 0.1
DECLARE @ft2 FLOAT = 0.2




SELECT @ft1 + @ft2 Good_Result
      ,CASE WHEN @ft1 + @ft2 = .3 THEN 1 ELSE 0 END Bad_Result
	  ,CASE WHEN CAST(@ft1 + @ft2 AS DECIMAL(18,2))= .3 THEN 1 ELSE 0 END Good_Result
GO








DECLARE @SomeValue FLOAT(1) = 0.0

WHILE @SomeValue <> 5.0
BEGIN
	PRINT @SomeValue;
	SET @SomeValue += 0.1;
END
GO












DECLARE @floatValue DECIMAL(18,2) = 0.0

WHILE @floatValue <> 5.0
BEGIN
	PRINT @floatValue;
	SET @floatValue += 0.1;
END 









/******************************************************************************************
	REMOVE DUPS
*/
SET NOCOUNT ON;
GO

DROP TABLE IF EXISTS #Employee
GO

CREATE TABLE #Employee
    ( 
    [ID] INT identity(1,1), 
    [FirstName] Varchar(100), 
    [LastName] Varchar(100), 
    [Country] Varchar(100), 
    ) 
    GO 
    
INSERT INTO #Employee ([FirstName],[LastName],[Country] )
VALUES  ('Raj','Gupta','India'),
        ('Raj','Gupta','India'),
        ('Mohan','Kumar','USA'),
        ('James','Barry','UK'),
        ('James','Barry','UK'),
        ('James','Barry','UK')
GO



SELECT * FROM #Employee   
GO









SELECT DISTINCT 
    FirstName,
    LastName,
    Country 
FROM #Employee
GO

SELECT  
    FirstName,
    LastName,
    Country 
FROM #Employee
GROUP BY FirstName,
         LastName,
         Country 
GO

--Bad Query
-- Just to retrieve the id
SELECT *
    FROM #Employee
    WHERE ID NOT IN
    (
        SELECT MAX(ID)
        FROM #Employee
        GROUP BY [FirstName], 
                 [LastName], 
                 [Country]
    );
GO





-- hard to return the id number as it is unique
SELECT [FirstName], 
    [LastName], 
    [Country], 
    COUNT(*) AS CNT
FROM #Employee
GROUP BY [FirstName], 
      [LastName], 
      [Country]
HAVING COUNT(*) > 1;
GO







WITH CTE(
    [Old_Id],
    [FirstName], 
    [LastName], 
    [Country], 
    DuplicateCount
	)
AS (SELECT Id,
           [FirstName], 
           [LastName], 
           [Country], 
           ROW_NUMBER() OVER(PARTITION BY [FirstName], 
                                          [LastName], 
                                          [Country]
           ORDER BY ID) AS DuplicateCount
    FROM #Employee)
SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS [NewId],
       [Old_Id], [FirstName], [LastName], [Country]
FROM CTE
WHERE DuplicateCount = 1;
GO